(function(){
    'use strict';

    angular
    .module('fjs.core', [
        'ngRoute',
        'ngResource'
    ]);

})();
