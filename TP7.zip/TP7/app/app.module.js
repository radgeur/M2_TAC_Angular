(function(){
    'use strict';

    angular
    .module('fjs', [
        'fjs.core',
        'fjs.services',
        'fjs.hello'
    ]);

})();
