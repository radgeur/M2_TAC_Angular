(function(){
    'use strict';

    angular
    .module('fjs.services', []);

})();
