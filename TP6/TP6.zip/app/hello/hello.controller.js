(function(){
    'use strict';
    
    angular
    .module('fjs.hello')
    .controller('HelloController', helloController);
    
    function helloController($filter) {
        var vm = this;
    }
    
})();