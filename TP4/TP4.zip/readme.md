# TP4 - “Two-way data-binding”

Durée : 30 min
Documentation officielle : https://docs.angularjs.org/tutorial/step_06

## Etape 1 : utiliser la directive ng-model

 1. Dans le fichier app/hello/**hello.html**, créer un champ texte et y placer la directive ng-model.
 
> Modifier la valeur du champs texte et constater que l'affichage évolue.
 
## BONUS : validation de formulaire

Le champs texte précédement créé est obligatoire.
Faire en sorte d'afficher un message si celui-ci n'est pas renseigné et de bloquer l'envoi.

Un indice : https://docs.angularjs.org/api/ng/directive/form
A vous de jouer !!